# 顾雅彬（二改版）

本仓库为 **DSH GO** 的二次修改版本。

- 原版：**DSH GO**
- 二改说明：仅修改应用显示名与 APK 产物文件名，未改动原项目业务逻辑、UI、容器（远程桌面 / 终端）及插件市场实现。
- 显示名：顾雅彬
- 标注：二改版 · 原版 DSH GO

## 目录放置要求

本仓库中的 `android/` 目录用于替换原工程同名目录，`pubspec.yaml` 中的 path 依赖保持原样：

```yaml
dsh_client:
  path: packages/dsh_client
dsh_remote:
  path: packages/dsh_remote
```

`lib/`、`packages/`、`android/`、`pubspec.yaml`、`l10n.yaml` 必须位于**同一层**（仓库根目录），不可嵌套。

## 编译

```bash
flutter pub get
flutter build apk --release
```

产物：`build/app/outputs/flutter-apk/app-release.apk`
重命名后产物：`android/app/build/outputs/renamed-apk/`
