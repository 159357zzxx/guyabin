// ============================================================
// 顾雅彬二改：APK 产物重命名（追加到 android/app/build.gradle 末尾）
// 说明：Flutter 最终产物在 build/app/outputs/flutter-apk/，
//       不受 applicationVariants 改名影响；AGP 9 起该 API 已弃用/移除，
//       因此采用 Gradle 任务在产物生成后复制重命名（原 APK 保留）。
// 注意：只改文件名，不改 applicationId。
// ============================================================
afterEvaluate {
    tasks.register("renameGuApk", Copy) {
        def vName = android.defaultConfig.versionName
        def vCode = android.defaultConfig.versionCode
        from(layout.buildDirectory.dir("outputs/flutter-apk")) {
            include "*.apk"
        }
        into(layout.buildDirectory.dir("outputs/renamed-apk"))
        rename { String f ->
            def m = (f =~ /(arm64-v8a|armeabi-v7a|x86_64|x86)/)
            def abi = m.find() ? m[0][0] : "universal"
            "顾雅彬_二改_DSHGO_${abi}-v${vName}+${vCode}.apk"
        }
    }
    tasks.matching { it.name.startsWith("assemble") }.configureEach { t ->
        t.finalizedBy("renameGuApk")
    }
}
