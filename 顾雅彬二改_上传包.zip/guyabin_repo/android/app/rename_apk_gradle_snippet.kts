// ============================================================
// 顾雅彬二改：APK 产物重命名（Kotlin DSL 版）
// 仅当 android/app/build.gradle.kts 存在时使用，
// 内容追加到该文件末尾。Groovy 版请用 .groovy 文件。
// ============================================================
afterEvaluate {
    tasks.register<Copy>("renameGuApk") {
        val vName = android.defaultConfig.versionName
        val vCode = android.defaultConfig.versionCode
        from(layout.buildDirectory.dir("outputs/flutter-apk")) { include("*.apk") }
        into(layout.buildDirectory.dir("outputs/renamed-apk"))
        rename { f: String ->
            val abi = Regex("arm64-v8a|armeabi-v7a|x86_64|x86").find(f)?.value ?: "universal"
            "顾雅彬_二改_DSHGO_${abi}-v${vName}+${vCode}.apk"
        }
    }
    tasks.matching { it.name.startsWith("assemble") }.configureEach { it.finalizedBy("renameGuApk") }
}
